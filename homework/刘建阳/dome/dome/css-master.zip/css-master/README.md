Assorted CSS and UI experiments from [@hakimel](http://twitter.com/hakimel).

Live demos:
- Cloudy Spiral http://lab.hakim.se/cloudy-spiral/
- Flexing Pagination http://lab.hakim.se/flexing-pagination/
- Device Loop http://lab.hakim.se/device-loop/
- Checkwave http://lab.hakim.se/checkwave/
- Monocle List http://lab.hakim.se/monocle/
- Flipside http://lab.hakim.se/flipside/

Copyright (C) 2015 Hakim El Hattab, http://hakim.se
