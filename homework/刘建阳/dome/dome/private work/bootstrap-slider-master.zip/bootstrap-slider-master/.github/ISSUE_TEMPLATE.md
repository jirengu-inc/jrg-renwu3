Issues
=============
**NOTE:** Before filing a new issue, please search through the open issues list and check to see if an existing issue already exists that describes your problem. If so, leave a comment within that issue with the checklist items described below.

Please make sure you include the following in your issue report where appropriate:

- [ ] JSFiddle (or an equivalent such as CodePen, Plunker, etc) with the an example demonstrating the bug
- [ ] Instructions to replicate the bug in the Fiddle

